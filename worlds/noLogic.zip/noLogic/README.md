# No Logic - Archipelago World

A special Archipelago world that removes all logic from a multiworld session, making every location in every world immediately accessible from the game start.

## Overview

**No Logic** is a utility world designed to bypass access rules entirely. When included in a multiworld:

- Every location becomes accessible without requiring any items
- All entrances are always open
- Event locations are unrestricted
- The session becomes entirely open for exploration from the beginning

## Installation

1. Place the `noLogic/` folder in `worlds/`
2. The world will be automatically registered with Archipelago

## Usage

### Minimal Setup (Recommended)

The absolute minimum to add No Logic to your session:

1. Create a file `players/NoLogic.yaml`:
```yaml
No Logic:
```

That's it! This single line adds No Logic with all default settings (everything accessible, progression items enabled).

2. Run generation normally:
```bash
python Generate.py --player_files_path players/
```

### Setup with Template

If you prefer more detailed configuration:

1. Copy `worlds/noLogic/NoLogic.yaml.template` to `players/NoLogic.yaml`
2. Edit the options as needed
3. Run generation

### Advanced Setup

For fully custom options:

```yaml
# NoLogic.yaml
No Logic:
  add_progression_item: true
  progression_item_type: global
  no_progression_maze: false
```

### Options

#### `add_progression_item` (Default: `true`)
- **Type:** Toggle
- **Description:** Whether to add a special "Progression Grant" item to the pool
- When enabled, a progression-classified item is added which can be used with ItemLinks

#### `progression_item_type` (Default: `global`)
- **Type:** Choice (`per_world` or `global`)
- **Description:** How progression items should be distributed (for documentation/planning purposes)
  - `per_world`: Suggests adding one item per world that grants that world's progression
  - `global`: Suggests a single item that satisfies all worlds' progression needs

#### `no_progression_maze` (Default: `false`)
- **Type:** Toggle
- **Description:** RISKY - Skip this unless you know what you're doing
- When enabled, removes original progression items and relies only on the special progression item
- **Warning:** This can make games unwinnable if items are dropped/lost

## Advanced: Using with ItemLinks

To grant players access to all progression items from the start without traditional logic, use Archipelago's built-in `item_links` option in other worlds' YAML files.

### Example: Per-World Progression Links

Create a player file with ItemLinks that groups each world's progression:

```yaml
Stardew Valley:
  # ... other options ...
  item_links:
    - name: "Stardew Progression"
      item_pool:
        - Spring Foraging Seed
        - Summer Foraging Seed
        - Fall Foraging Seed
        - Winter Foraging Seed
        # ... more progression items

The Legend of Zelda: A Link to the Past:
  # ... other options ...
  item_links:
    - name: "ALTTP Progression"
      item_pool:
        - Bomb
        - Shield
        - Sword
        # ... more progression items
```

### Example: Global Progression Link

Link all worlds' progression into a single group:

```yaml
Stardew Valley:
  item_links:
    - name: "Everything Goes"
      item_pool:
        - Spring Foraging Seed
        - Bomb
        - Key
        # ... all progression from all worlds combined
```

## How It Works

### Stage 1: Rule Removal
When generation reaches the `stage_set_rules` phase, No Logic:
1. Detects its presence in the multiworld
2. Iterates through all regions, entrances, and locations
3. Replaces every access rule with `lambda state: True`
4. Logs the number of rules removed

**Result:** All locations become accessible immediately without any item requirements.

### Stage 2: Item Pool
No Logic maintains a minimal item pool:
- One location (for logical completeness)
- One or more items depending on options

This is intentionally minimal since the goal is empty world exploration, not progression within No Logic.

## Use Cases

1. **Testing Archipelago Configurations**
   - Run multiple games together without logic to test multiworld setup
   - Verify item distribution works correctly

2. **Race/Speed-Run Servers**
   - Host sessions where players explore and complete games at their own pace
   - No logic gates or progression requirements

3. **Cooperative Mode**
   - Play through multiple games together knowing every location is accessible
   - Focus on completion rather than puzzle-solving

4. **Content Creation**
   - Record multiworld sessions without time spent waiting for progression
   - Demonstrate game integration without logic complications

## Technical Details

### World Inheritance
- Inherits from `worlds.AutoWorld.World`
- Uses `stage_set_rules` class method to globally modify rules after all worlds have set their rules
- This ensures No Logic's rule removal happens at the right point in generation

### Item Classification
- `Progression Grant`: Classified as `ItemClassification.progression` for use in ItemLinks
- Other items: `ItemClassification.filler` for padding the pool

### ID Space
- Items: `100_000` - `100_001`
- Locations: `100_000`

These ranges are intentionally high to avoid conflicts with other worlds.

## Troubleshooting

### "No Logic location is unreachable"
- This is expected. No Logic's single location doesn't need to be reachable within any specific world
- It's placed in its own region and is never part of puzzle-solving logic

### Error: "Item link contains items from No Logic world"
- ItemLinks should include items from other worlds only
- No Logic's items (`Progression Grant`, `Filler`) are minimal and not meant for linking

### Generation fails with No Logic included
- Verify your YAML syntax is correct
- Ensure other worlds in the multiworld have no conflicting item IDs in the `100_000` range (unlikely but possible)
- Check logs in the `logs/` directory for detailed error messages

## Contributing

To improve this world or add features:

1. Modify [Options.py](Options.py) to add new configuration options
2. Update [__init__.py](__init__.py) with corresponding logic
3. Test through the standard Archipelago generation pipeline
4. Update this README with new features

## License

MIT License - See LICENSE file in the repository

## Credits

Created as a utility world for Archipelago multiworld randomizer sessions.
